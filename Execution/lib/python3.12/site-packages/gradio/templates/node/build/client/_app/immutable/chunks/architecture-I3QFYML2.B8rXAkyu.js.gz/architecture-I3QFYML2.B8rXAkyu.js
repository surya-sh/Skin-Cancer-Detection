import { A, e } from "./mermaid-parser.core.FEcevPec.js";
export {
  A as ArchitectureModule,
  e as createArchitectureServices
};
