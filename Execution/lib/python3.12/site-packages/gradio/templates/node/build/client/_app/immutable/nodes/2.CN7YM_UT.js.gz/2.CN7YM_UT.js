import { V, _ } from "../chunks/2.C93YFD0R.js";
export {
  V as component,
  _ as universal
};
