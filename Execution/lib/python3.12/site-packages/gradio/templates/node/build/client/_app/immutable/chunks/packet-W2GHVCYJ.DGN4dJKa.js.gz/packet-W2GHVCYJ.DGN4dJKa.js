import { P, a } from "./mermaid-parser.core.FEcevPec.js";
export {
  P as PacketModule,
  a as createPacketServices
};
