import { I, c } from "./mermaid-parser.core.FEcevPec.js";
export {
  I as InfoModule,
  c as createInfoServices
};
